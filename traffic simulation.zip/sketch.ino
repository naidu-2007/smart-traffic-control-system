
#include <Arduino.h>

// Smart Traffic Controller - Wokwi timing test
// Serial Monitor: 9600 baud
// Commands: E1-E4 emergency, P1-P4 pedestrian

const byte R[4] = {2, 5, 8, 11};
const byte Y[4] = {3, 6, 9, 12};
const byte G[4] = {4, 7, 10, 13};
const byte D[4] = {A0, A1, A2, A3};

const unsigned long GREEN_MIN = 15000UL;
const unsigned long GREEN_MAX = 90000UL;
const unsigned long YELLOW_MS = 3000UL;
const unsigned long ALL_RED_MS = 2000UL;
const unsigned long PED_LIMIT = 120000UL;

enum Phase : byte { GREEN_PHASE, YELLOW_PHASE, ALL_RED_PHASE };
Phase phase = ALL_RED_PHASE;

byte currentRoad = 0;
byte emergencyRoad = 0;
byte pedMask = 0;

int density[4] = {0, 0, 0, 0};
unsigned long pedTime[4] = {0, 0, 0, 0};

unsigned long phaseTime = 0;
unsigned long greenTime = GREEN_MIN;
unsigned long densityTime = 0;
unsigned long emergencyTime = 0;
unsigned long handlerUs = 0;

bool emergencyPending = false;
bool emergencyTiming = false;

// Put all vehicle lights at red
void allRed() {
  for (byte i = 0; i < 4; i++) {
    digitalWrite(R[i], HIGH);
    digitalWrite(Y[i], LOW);
    digitalWrite(G[i], LOW);
  }
}

// Start yellow clearance
void startYellow() {
  digitalWrite(G[currentRoad], LOW);
  digitalWrite(Y[currentRoad], HIGH);
  digitalWrite(R[currentRoad], LOW);
  phase = YELLOW_PHASE;
  phaseTime = millis();
  Serial.println(F("Yellow clearance started"));
}

// Start all-red clearance
void startAllRed() {
  allRed();
  phase = ALL_RED_PHASE;
  phaseTime = millis();
  Serial.println(F("All-red clearance started"));
}

// Start green for a road
void setGreen(byte road) {
  allRed();

  digitalWrite(R[road], LOW);
  digitalWrite(G[road], HIGH);

  currentRoad = road;
  phase = GREEN_PHASE;
  phaseTime = millis();

  greenTime = GREEN_MIN +
    (unsigned long)density[road] *
    (GREEN_MAX - GREEN_MIN) / 1023UL;

  Serial.print(F("Road "));
  Serial.print(road + 1);
  Serial.print(F(" GREEN, duration seconds="));
  Serial.println(greenTime / 1000UL);

  // Report emergency request-to-green latency
  if (emergencyTiming && road == emergencyRoad - 1) {
    unsigned long elapsed = millis() - emergencyTime;

    Serial.println(F("=== EMERGENCY RESULT ==="));
    Serial.print(F("Handler execution us="));
    Serial.println(handlerUs);
    Serial.print(F("Request-to-green ms="));
    Serial.println(elapsed);
    Serial.println(elapsed <= 500
      ? F("500 ms target: PASS")
      : F("500 ms target: FAIL"));
    Serial.println(F("========================"));

    emergencyTiming = false;
    emergencyPending = false;
  }
}

// Choose emergency first, then oldest pedestrian request,
// otherwise choose the road with the highest density.
byte chooseRoad() {
  if (emergencyPending) return emergencyRoad - 1;

  byte chosen = 255;
  unsigned long longestWait = 0;
  unsigned long now = millis();

  for (byte i = 0; i < 4; i++) {
    if (pedMask & (byte)(1U << i)) {
      unsigned long wait = now - pedTime[i];
      if (chosen == 255 || wait > longestWait) {
        chosen = i;
        longestWait = wait;
      }
    }
  }

  if (chosen != 255) {
    pedMask &= (byte)~(1U << chosen);

    Serial.println(F("=== PEDESTRIAN RESULT ==="));
    Serial.print(F("Road served="));
    Serial.println(chosen + 1);
    Serial.print(F("Request-to-service ms="));
    Serial.println(longestWait);
    Serial.println(longestWait <= PED_LIMIT
      ? F("120 second target: PASS")
      : F("120 second target: FAIL"));
    Serial.println(F("========================="));

    return chosen;
  }

  byte best = (currentRoad + 1) % 4;

  for (byte n = 1; n <= 4; n++) {
    byte road = (currentRoad + n) % 4;
    if (density[road] > density[best]) best = road;
  }

  return best;
}

// Update potentiometer readings every two seconds
void updateDensity() {
  if (millis() - densityTime >= 2000UL) {
    densityTime = millis();

    for (byte i = 0; i < 4; i++) {
      density[i] = analogRead(D[i]);
    }

    Serial.print(F("Density "));
    for (byte i = 0; i < 4; i++) {
      Serial.print(F("R"));
      Serial.print(i + 1);
      Serial.print('=');
      Serial.print(density[i]);
      Serial.print(' ');
    }
    Serial.println();
  }
}

// Read serial commands even if characters arrive separately
void processSerial() {
  static char command = 0;

  while (Serial.available() > 0) {
    char c = Serial.read();

    if (c == '\n' || c == '\r' || c == ' ' || c == '\t')
      continue;

    if (c >= 'a' && c <= 'z') c -= ('a' - 'A');

    if (c == 'E' || c == 'P') {
      command = c;
      continue;
    }

    if (c < '1' || c > '4' || command == 0) {
      command = 0;
      Serial.println(F("Use E1-E4 or P1-P4"));
      continue;
    }

    byte road = c - '0';

    if (command == 'E') {
      unsigned long startUs = micros();

      emergencyRoad = road;
      emergencyPending = true;
      emergencyTime = millis();
      emergencyTiming = true;

      if (phase == GREEN_PHASE) startYellow();

      handlerUs = micros() - startUs;

      Serial.print(F("Emergency accepted for road "));
      Serial.println(road);
      Serial.print(F("Handler execution us="));
      Serial.println(handlerUs);
      Serial.println(F("Yellow/all-red safety clearance retained."));
    } else {
      byte mask = (byte)(1U << (road - 1));

      if (!(pedMask & mask)) {
        pedMask |= mask;
        pedTime[road - 1] = millis();
      }

      Serial.print(F("Pedestrian request queued for road "));
      Serial.println(road);
    }

    command = 0;
  }
}

// Arduino setup
void setup() {
  Serial.begin(9600);

  for (byte i = 0; i < 4; i++) {
    pinMode(R[i], OUTPUT);
    pinMode(Y[i], OUTPUT);
    pinMode(G[i], OUTPUT);
    density[i] = analogRead(D[i]);
  }

  allRed();
  densityTime = millis();

  Serial.println(F("Smart Traffic Controller timing test"));
  Serial.println(F("Commands: E1-E4 emergency, P1-P4 pedestrian"));

  startAllRed();
}

// Arduino loop
void loop() {
  processSerial();
  updateDensity();

  unsigned long now = millis();

  if (phase == GREEN_PHASE) {
    if (emergencyPending || now - phaseTime >= greenTime)
      startYellow();
  }
  else if (phase == YELLOW_PHASE) {
    if (now - phaseTime >= YELLOW_MS)
      startAllRed();
  }
  else if (phase == ALL_RED_PHASE) {
    if (now - phaseTime >= ALL_RED_MS)
      setGreen(chooseRoad());
  }
}
